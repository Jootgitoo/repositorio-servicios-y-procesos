

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyPair;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

/**
 * Clase Servidor para tratar el mensaje enviado por cada cliente
 *
 */
public class ServidorHilo extends Thread {

	private Socket cliente;
	private KeyPair claves;
	private Cipher cifrador;


	public ServidorHilo(Socket socket, KeyPair claves) throws NoSuchAlgorithmException, NoSuchPaddingException {
		this.cliente = socket;//conexi�n con el cliente
		this.claves = claves;//claves del servidor
		cifrador = Cipher.getInstance("RSA");
	}

	private void escuchar() throws Exception {
		
		try {

			// Mandar la clave publica del servidor al cliente
			ObjectOutputStream oos;
			try {
				oos = new ObjectOutputStream(cliente.getOutputStream());
				oos.writeObject(claves.getPublic());
			} catch (IOException e) {
				e.printStackTrace();
				throw e;
			}
						
			// Recibe el mensaje del cliente encriptado
			ObjectInputStream ois = null;
			try {
				ois = new ObjectInputStream(cliente.getInputStream());
				String mensaje = (String) ois.readObject();
				
				System.out.println("Mensaje cifrado: "+mensaje);		
				byte[] mensajeDescifrado = descifrar(Base64.getDecoder().decode(mensaje), claves.getPrivate());
				String mensajeDes = new String(mensajeDescifrado,"UTF-8");
				System.out.println("El mesaje descifrado es: "+mensajeDes);
						
			} catch (IOException | InvalidKeyException | IllegalBlockSizeException | BadPaddingException e) {
				e.printStackTrace();
				throw e;
			}
			
		} finally {

			try {
				if (null != cliente) {
					cliente.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	private byte[] descifrar(byte[] paraDescifrar, Key claveDescifrado)
			throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
		// Se pone el cifrador en modo descifrado
		cifrador.init(Cipher.DECRYPT_MODE, claveDescifrado);
		// Desencriptamos
		byte[] resultado = cifrador.doFinal(paraDescifrar);
		return resultado;
	}
	
	@Override
	public void run() {
		try {
			escuchar();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
