import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

public class Cliente {
	KeyPair claves;//Clave publica y privada
	KeyPairGenerator generadorClaves;
	Cipher cifrador;
	
	public Cliente() throws NoSuchAlgorithmException, NoSuchPaddingException {
		//Generador de claves: RSA
		generadorClaves = KeyPairGenerator.getInstance("RSA");
		/*
		 * Usaremos una longitud de clave de 1024 bits
		 */
		generadorClaves.initialize(1024);
		//Generamos la clave publica y privada
		claves = generadorClaves.generateKeyPair();
		cifrador = Cipher.getInstance("RSA");
	}

	/**
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args) throws Exception {
		Cliente cliente = new Cliente();
		cliente.escribir();
	}
	
	private byte[] cifrar(byte[] paraCifrar, Key claveCifrado)
			throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
		// Se pone el cifrador en modo cifrado, y se le pasa la clave para encriptar
		cifrador.init(Cipher.ENCRYPT_MODE, claveCifrado);
		// Encripta los datos
		byte[] resultado = cifrador.doFinal(paraCifrar);
		return resultado;

	}
	
	public void escribir() throws Exception {
		Socket socket = null;
		ObjectInputStream ois = null;
		ObjectOutputStream oos = null;
		try {
			//Conectarse con el servidor
			InetSocketAddress direccion = new InetSocketAddress("localhost", 9876);
			socket = new Socket();
			socket.connect(direccion);
			
			//recoger clave publica del servidor
			ois = new ObjectInputStream(socket.getInputStream());
			PublicKey publicKey = (PublicKey) ois.readObject();
			System.out.println("Recibida clave publica del servidor:"+publicKey);			
			
			//Enviar un mensaje al servidor, encriptado con la clave publica del servidor
			byte[] mensajeCifrado = cifrar("Hola Mundo".getBytes(), publicKey);
			String cadCifrada = Base64.getEncoder().encodeToString(mensajeCifrado);
			System.out.println("Mensaje Cifrado: "+cadCifrada);
			oos = new ObjectOutputStream(socket.getOutputStream());
			oos.writeObject(cadCifrada);			
		}
		catch(IOException | ClassNotFoundException | InvalidKeyException | IllegalBlockSizeException | BadPaddingException e) {
			e.printStackTrace();
			throw e;
		}
		finally {
			if(null != ois) {
				try {
					ois.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if(null != oos) {
				try {
					oos.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (null != socket) {
				try {
					socket.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
