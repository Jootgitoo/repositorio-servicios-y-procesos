import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;

import javax.crypto.NoSuchPaddingException;

public class Servidor {
	KeyPair claves;//Clave publica y privada
	KeyPairGenerator generadorClaves;
	
	public Servidor() throws NoSuchAlgorithmException, NoSuchPaddingException {
		//Generador de claves: RSA
		generadorClaves = KeyPairGenerator.getInstance("RSA");
		/*
		 * Usaremos una longitud de clave de 1024 bits
		 */
		generadorClaves.initialize(1024);
		//Generamos la clave publica y privada
		claves = generadorClaves.generateKeyPair();
	}
	
	public static void main(String[] args) throws Exception {
		Servidor servidor = new Servidor();
		servidor.escuchar();
	}

	public void escuchar() throws Exception {
		
		System.out.println("Arrancando el servidor");
		ServerSocket socketEscucha = null;
		ServidorHilo hilo = null;
		try {
			socketEscucha = new ServerSocket(9876);
			while (true) {
				try {
					Socket conexion = socketEscucha.accept();
					System.out.println("Conexion recibida");
					//Se abre un hilo por cada conexi�n cliente que llegue
					hilo = new ServidorHilo(conexion, claves);
					hilo.start();
				} catch (IOException e) {
					e.printStackTrace();
					throw e;
				}
			}

		} catch (IOException e) {
			e.printStackTrace();
			throw e;
		} finally {
			try {
				if (null != socketEscucha) {
					socketEscucha.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}	
	
}
