import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLServerSocket;
import javax.net.ssl.SSLServerSocketFactory;

public class ServidorSeguro {
	
	private String rutaAlmacen;
	private String claveAlmacen;
	
	public ServidorSeguro(String rutaAlmacen, String claveAlmacen) {
		this.rutaAlmacen = rutaAlmacen;
		this.claveAlmacen = claveAlmacen;
	}

	private SSLServerSocket getServerSocketSeguro(int puerto) throws KeyStoreException, NoSuchAlgorithmException,
			CertificateException, IOException, KeyManagementException, UnrecoverableKeyException {
		
		SSLServerSocket serverSocket = null;
		FileInputStream fichAlmacen=null;
		try {
			/* Paso 1, se carga el almac�n de claves */
			fichAlmacen = new FileInputStream(this.rutaAlmacen);
			/*
			 * Paso 1.1, se crea un almac�n del tipo por defecto que es un JKS (Java Key
			 * Store), a d�a de hoy
			 */
			KeyStore almacen = KeyStore.getInstance(KeyStore.getDefaultType());
			almacen.load(fichAlmacen, claveAlmacen.toCharArray());
			/*
			 * Paso 2: obtener una f�brica de KeyManagers que ofrezcan soporte al algoritmo
			 * por defecto
			 */
			KeyManagerFactory fabrica = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
			fabrica.init(almacen, claveAlmacen.toCharArray());
			/*
			 * Paso 3:Intentamos obtener un contexto SSL que ofrezca soporte a TLS (el
			 * sistema m�s seguro hoy d�a)
			 */
			SSLContext contextoSSL = SSLContext.getInstance("TLS");
			contextoSSL.init(fabrica.getKeyManagers(), null, null);
			/*
			 * Paso 4: Se obtiene una f�brica de sockets que permita obtener un
			 * SSLServerSocket
			 */
			SSLServerSocketFactory fabricaSockets = contextoSSL.getServerSocketFactory();
			serverSocket = (SSLServerSocket) fabricaSockets.createServerSocket(puerto);
		}
		catch(KeyStoreException | NoSuchAlgorithmException | CertificateException | IOException | KeyManagementException | UnrecoverableKeyException e) {
			e.printStackTrace();
			throw e;
		}
		finally {
			if (null != fichAlmacen) {
				fichAlmacen.close();
			}
		}
		return serverSocket;
	}

	public void escuchar(int puerto)
        throws KeyManagementException, UnrecoverableKeyException,
            KeyStoreException, NoSuchAlgorithmException,
            CertificateException, IOException
    {
		BufferedReader entrada = null;
        PrintWriter salida = null;
        SSLServerSocket socketServidor = null;
        Socket connRecibida = null;
        try {    
			socketServidor=this.getServerSocketSeguro(puerto);
	        while (true){
	        	try {
	                connRecibida=socketServidor.accept();
	                System.out.println("Conexion segura recibida");
	                entrada=
	                    new BufferedReader(
	                    new InputStreamReader(connRecibida.getInputStream()));
	                salida=
	                    new PrintWriter(
	                        new OutputStreamWriter(
	                        connRecibida.getOutputStream()));
	                String linea=entrada.readLine();
	                System.out.println("Msg recibido: "+linea);
	                salida.println(linea.length());
	                salida.flush();
	        	}
	        	catch(IOException e) {
	        		e.printStackTrace();
	        		throw e;
	        	}
	        	finally {
	    			if (null != connRecibida) {
	    				connRecibida.close();
	    			}
	    			if (null != entrada) {
	    				entrada.close();
	    			}
	    			if (null != salida) {
	    				salida.close();
	    			}
	    		}
	        }
        }
        catch(KeyStoreException | NoSuchAlgorithmException | CertificateException | IOException | KeyManagementException | UnrecoverableKeyException e) {
			e.printStackTrace();
			throw e;
		}
		finally {
			if (null != socketServidor) {
				socketServidor.close();
			}
		}
    }
	
	public static void main(String[] args) throws Exception {
		String rutaAlmacen = "AlmacenClaves";
		String claveAlmacen = "claveAlmacen";
		ServidorSeguro servidor = new ServidorSeguro(rutaAlmacen, claveAlmacen);
		servidor.escuchar(9876);
	}
}
