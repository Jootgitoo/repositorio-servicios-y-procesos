import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.UnknownHostException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManagerFactory;

public class ClienteServidorSeguro {

	String almacen = "AlmacenReceptor";
	String clave = "clavereceptor";
	SSLSocket conexion;

	public ClienteServidorSeguro(String ip, int puerto)
	                    throws UnknownHostException, IOException,
	                    KeyManagementException, NoSuchAlgorithmException,
	                    KeyStoreException, CertificateException{

           conexion=this.obtenerSocket(ip,puerto);
    }

	/*
	 * Env�a un mensaje de prueba para verificar que la conexi�n SSL es correcta
	 */
	public void conectar() throws IOException {
		InputStreamReader isr = null;
		BufferedReader entrada = null;
		OutputStreamWriter osw = null;
		PrintWriter salida = null;
		try  {
			System.out.println("Iniciando..");
			isr = new InputStreamReader(conexion.getInputStream());
			entrada = new BufferedReader(isr);
			osw = new OutputStreamWriter(conexion.getOutputStream());
			salida = new PrintWriter(osw);
			/* De esta linea se intenta averiguar la longitud */
			salida.println("1234567890");
			salida.flush();
			
			/* Si todo va bien, el servidor nos contesta el numero */
			String num = entrada.readLine();
			int longitud = Integer.parseInt(num);
			
			System.out.println("La longitud devuelta es:" + longitud);
		}
		catch(IOException e) {
			e.printStackTrace();
			throw e;
		}
		finally {
			if (null != salida) {
				salida.close();
			}
			if (null != osw) {
				osw.close();
			}
			if (null != entrada) {
				entrada.close();
			}
			if (null != isr) {
				isr.close();
			}
		}
	}

	private SSLSocket obtenerSocket(String ip, int puerto) throws KeyStoreException, NoSuchAlgorithmException,
			CertificateException, IOException, KeyManagementException {
		System.out.println("Obteniendo socket");
		SSLSocket socket = null;
		FileInputStream ficheroAlmacenClaves = null;
		try {
			/*
			 * Paso 1: se carga al almac�n de claves (que recordemos debe contener el
			 * certificado del servidor)
			 */
			KeyStore almacenCliente = KeyStore.getInstance(KeyStore.getDefaultType());
			ficheroAlmacenClaves = new FileInputStream(this.almacen);
			almacenCliente.load(ficheroAlmacenClaves, clave.toCharArray());
			System.out.println("Almacen cargado");
			/*
			 * Paso 2, crearemos una fabrica de gestores de confianza que use el almac�n
			 * cargado antes (que contiene el certificado del servidor)
			 */
			TrustManagerFactory fabricaGestoresConfianza = TrustManagerFactory
					.getInstance(TrustManagerFactory.getDefaultAlgorithm());
			fabricaGestoresConfianza.init(almacenCliente);
			System.out.println("Fabrica Trust creada");
			/*
			 * Paso 3: se crea el contexto SSL, que ofrezca soporte al algoritmo TLS
			 */
			SSLContext contexto = SSLContext.getInstance("TLS");
			contexto.init(null, fabricaGestoresConfianza.getTrustManagers(), null);
			/* Paso 4: Se crea un socket que conecte con el servidor */
			System.out.println("Contexto creado");
			SSLSocketFactory fabricaSockets = contexto.getSocketFactory();
			socket = (SSLSocket) fabricaSockets.createSocket(ip, puerto);
			/* Y devolvemos el socket */
			System.out.println("Socket creado");
		}
		catch(KeyStoreException | NoSuchAlgorithmException |
			CertificateException | IOException | KeyManagementException e) {
			e.printStackTrace();
			throw e;
		}
		finally {
			if (null != ficheroAlmacenClaves) {
				ficheroAlmacenClaves.close();
			}
		}
		return socket;
	}

	public static void main(String[] args) throws Exception {
		ClienteServidorSeguro cliente = new ClienteServidorSeguro("localhost", 9876);
		cliente.conectar();

	}

}
