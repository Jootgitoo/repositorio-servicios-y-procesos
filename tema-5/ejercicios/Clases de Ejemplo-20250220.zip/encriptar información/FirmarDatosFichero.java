import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.PrivateKey;
import java.security.Signature;

public class FirmarDatosFichero {

	public static void main(String[] args) throws Exception {
		// Genera la firma del fichero a partir de la clave privada almacenada en el fichero clave.privada
		// La firma se almacena en el fichero fichero.firma
		
		FileInputStream fichero=null;
		BufferedInputStream bis=null;
		FileOutputStream fos = null;
		try {
			//Leer clave privada
			LeerClavesFichero leerClaves = new LeerClavesFichero();
			PrivateKey privateKey = leerClaves.readOfFilePrivateKey("clave.privada");
			
			//Inicializasr firma con clave privada
			Signature signature = Signature.getInstance("SHA256withRSA");
			signature.initSign(privateKey);
	        
	        //Lectura del fichero a firmar
	        fichero = new FileInputStream("fichero.data");
	        bis = new BufferedInputStream(fichero);
	        byte[] buffer = new byte[bis.available()];
	        int len;
	        while((len= bis.read(buffer)) >= 0) {
	        	signature.update(buffer, 0, len);
	        }
	        
	        //Genera la firma de los datos del fichero
	        byte[] firma = signature.sign();
	        
	        //Guarda la firma en otro fichero
	        fos = new FileOutputStream("fichero.firma");
			fos.write(firma);
		}
		catch(IOException e) {
			e.printStackTrace();
			throw e;
		}
		finally {
			if (null != fos) {
				fos.close();
			}
			if (null != bis) {
				bis.close();
			}
			if (null != fichero){
				fichero.close();
			}
		}

	}

}
