import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignatureException;
import java.security.spec.InvalidKeySpecException;

public class VerifySignature {

	public static void main(String[] args) throws Exception {
		// Verifica que fichero.firma es correcto.

		FileInputStream ficheroFirma = null;
		FileInputStream fichero = null;
		BufferedInputStream bis = null;
		try {
			// Leer clave publica del fichero
			LeerClavesFichero leerClaves = new LeerClavesFichero();
			PublicKey publicKey = leerClaves.readOfFilePublicKey("clave.publica");
			
			// Lectura del fichero que contiene la firma
			ficheroFirma = new FileInputStream("fichero.firma");
			byte[] firma = new byte[ficheroFirma.available()];
			ficheroFirma.read(firma); 

			// Inicializar firma con clave publica
			Signature signature = Signature.getInstance("SHA256withRSA");
			signature.initVerify(publicKey);

			// Lectura del fichero que contiene los datos a verificar
			fichero = new FileInputStream("fichero.data");
			bis = new BufferedInputStream(fichero);
	        byte[] buffer = new byte[bis.available()];
	        int len;
	        while((len= bis.read(buffer)) >= 0) {
	        	signature.update(buffer, 0, len);
	        } 
			
			// Verificar la firma de los datos leidos
			boolean booVerifica = signature.verify(firma);

			//comprobar la verificacion
			if (booVerifica) {
				System.out.println("Los datos se corresponden con su firma");
			}
			else {
				System.out.println("Los datos no se corresponden con su firma");
			}
		} catch (IOException | NoSuchAlgorithmException | SignatureException | InvalidKeySpecException | InvalidKeyException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (null != bis) {
				bis.close();
			}
			if (null != fichero) {
				fichero.close();
			}			
			if (null != ficheroFirma) {
				ficheroFirma.close();
			}
		}

	}

}
